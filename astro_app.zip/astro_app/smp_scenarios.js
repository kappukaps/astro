const smpScenarios = [
    {
        name: "Example 1: May 2026 (Workbook)",
        am: {
            hsd: 34, hsm: 43.0, ie: 1.8, ieArc: -1, hoe: 11,
            latd: 25, latm: 20.0, latDir: -1,
            lond: 43, lonm: 10.0, lonDir: -1,
            day: 16, mon: 5, yr: 2026,
            zh: 9, zm: 34, zs: 50,
            zdSign: 1, zdh: 3, zdm: 0, zds: 0,
            ghad: 9, gham: 37.1,
            decd: 19, decm: 10.4, decDir: 1
        },
        run: {
            cog: 110, sog: 15, eth: 2, etm: 14 // 14 for perfect fix, 21 was worksheet
        },
        lan: {
            hsd: 45, hsm: 7.6, ie: 1.8, ieArc: -1, hoe: 11,
            decd: 19, decm: 12.1, decDir: 1,
            day: 16, mon: 5, yr: 2026,
            zh: 11, zm: 56, zs: 0
        }
    },
    {
        name: "Example 2: July 2026 (Worksheet P3)",
        am: {
            hsd: 22, hsm: 37.8, ie: 2.0, ieArc: -1, hoe: 12,
            latd: 33, latm: 0.0, latDir: -1, // Chosen Lat 33 S
            lond: 50, lonm: 8.9, lonDir: -1, // Chosen Lon 50 08.9 W
            day: 14, mon: 7, yr: 2026,
            zh: 9, zm: 42, zs: 30,
            zdSign: 1, zdh: 3, zdm: 0, zds: 0,
            ghad: 9, gham: 8.9,
            decd: 21, decm: 37.4, decDir: 1
        },
        run: {
            cog: 75, sog: 16, eth: 2, etm: 23
        },
        lan: {
            hsd: 35, hsm: 20.4, ie: 2.0, ieArc: -1, hoe: 12,
            decd: 21, decm: 36.4, decDir: 1,
            day: 14, mon: 7, yr: 2026,
            zh: 12, zm: 6, zs: 0
        }
    }
];

function loadSMPScenario(idx) {
    const sc = smpScenarios[idx];
    if (!sc) return;

    // AM Sight
    document.getElementById('smp-am-hsd').value = sc.am.hsd;
    document.getElementById('smp-am-hsm').value = sc.am.hsm;
    document.getElementById('smp-am-ie').value = sc.am.ie;
    document.getElementById('smp-am-iearc').value = sc.am.ieArc;
    document.getElementById('smp-am-hoe').value = sc.am.hoe;
    document.getElementById('smp-am-latd').value = sc.am.latd;
    document.getElementById('smp-am-latm').value = sc.am.latm;
    document.getElementById('smp-am-latdir').value = sc.am.latDir;
    document.getElementById('smp-am-lond').value = sc.am.lond;
    document.getElementById('smp-am-lonm').value = sc.am.lonm;
    document.getElementById('smp-am-londir').value = sc.am.lonDir;
    document.getElementById('smp-am-day').value = sc.am.day;
    document.getElementById('smp-am-mon').value = sc.am.mon;
    document.getElementById('smp-am-yr').value = sc.am.yr;
    document.getElementById('smp-am-zt-h').value = String(sc.am.zh).padStart(2, '0');
    document.getElementById('smp-am-zt-m').value = String(sc.am.zm).padStart(2, '0');
    document.getElementById('smp-am-zt-s').value = String(sc.am.zs).padStart(2, '0');
    document.getElementById('smp-am-zone-sign').value = sc.am.zdSign;
    document.getElementById('smp-am-zone-h').value = sc.am.zdh;
    document.getElementById('smp-am-zone-m').value = sc.am.zdm;
    document.getElementById('smp-am-zone-s').value = sc.am.zds;
    document.getElementById('smp-am-ghad').value = sc.am.ghad;
    document.getElementById('smp-am-gham').value = sc.am.gham;
    document.getElementById('smp-am-decd').value = sc.am.decd;
    document.getElementById('smp-am-decm').value = sc.am.decm;
    document.getElementById('smp-am-decdir').value = sc.am.decDir;

    // Run
    document.getElementById('smp-cog').value = sc.run.cog;
    document.getElementById('smp-sog').value = sc.run.sog;
    document.getElementById('smp-eth').value = sc.run.eth;
    document.getElementById('smp-etm').value = sc.run.etm;

    // LAN
    document.getElementById('smp-lan-hsd').value = sc.lan.hsd;
    document.getElementById('smp-lan-hsm').value = sc.lan.hsm;
    document.getElementById('smp-lan-ie').value = sc.lan.ie;
    document.getElementById('smp-lan-iearc').value = sc.lan.ieArc;
    document.getElementById('smp-lan-hoe').value = sc.lan.hoe;
    document.getElementById('smp-lan-decd').value = sc.lan.decd;
    document.getElementById('smp-lan-decm').value = sc.lan.decm;
    document.getElementById('smp-lan-decdir').value = sc.lan.decDir;
    document.getElementById('smp-lan-day').value = sc.lan.day;
    document.getElementById('smp-lan-mon').value = sc.lan.mon;
    document.getElementById('smp-lan-yr').value = sc.lan.yr;
    document.getElementById('smp-lan-zt-h').value = String(sc.lan.zh).padStart(2, '0');
    document.getElementById('smp-lan-zt-m').value = String(sc.lan.zm).padStart(2, '0');
    document.getElementById('smp-lan-zt-s').value = String(sc.lan.zs).padStart(2, '0');

    console.log("Scenario loaded:", sc.name);

    // Auto-calculate everything with a small delay for UI updates
    setTimeout(() => {
        if (typeof nsSRcompute === 'function') nsSRcompute('smp-am');
        if (typeof nsSMPlan === 'function') nsSMPlan();
        if (typeof nsSMPfix === 'function') nsSMPfix();
    }, 50);
}
