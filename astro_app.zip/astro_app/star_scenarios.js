const starScenarios = [
    {
        name: "Example 1: July 2026 (Workbook Page 1)",
        ap: { latDir: -1, latD: 40, latM: 0, lonDir: -1, lonD: 60, lonM: 20 },
        ship: { cog: 72, sog: 12, hoe: 9, ie: 1.8, ieArc: -1 },
        date: { day: 20, mon: 7, yr: 2026 },
        zone: { sign: 1, h: 4, m: 0, s: 0 },
        bodies: [
            { name: "ARCTURUS", th: 18, tm: 22, ts: 40, hsd: 31, hsm: 15.3, ghad: 60, gham: 8.5, decd: 19, decm: 4.2, decdir: 1 },
            { name: "ANTARES", th: 18, tm: 24, ts: 20, hsd: 59, hsm: 40, ghad: 27, gham: 0.8, decd: 26, decm: 30.3, decdir: -1 },
            { name: "ACRUX", th: 18, tm: 26, ts: 0, hsd: 65, hsm: 30, ghad: 88, gham: 10.6, decd: 56, decm: 38.8, decdir: -1 },
            { name: "MIAPLACIDUS", th: 18, tm: 27, ts: 40, hsd: 41, hsm: 42, ghad: 137, gham: 15.7, decd: 69, decm: 51.5, decdir: -1 }
        ]
    },
    {
        name: "Example 2: April 2026 (Worksheet Q2 Page 1)",
        ap: { latDir: 1, latD: 14, latM: 40, lonDir: 1, lonD: 69, lonM: 20 },
        ship: { cog: 158, sog: 11, hoe: 10, ie: 1.4, ieArc: -1 },
        date: { day: 24, mon: 4, yr: 2026 },
        zone: { sign: -1, h: 4, m: 30, s: 0 },
        bodies: [
            { name: "REGULUS", th: 19, tm: 18, ts: 40, hsd: 82, hsm: 3.0, ghad: 282, gham: 22.1, decd: 11, decm: 50.2, decdir: 1 },
            { name: "MOON", th: 19, tm: 20, ts: 20, hsd: 77, hsm: 35.0, ghad: 301, gham: 25.8, decd: 19, decm: 26.5, decdir: 1, limb: "moon_ll", hp: 58.2 },
            { name: "ARCTURUS", th: 19, tm: 22, ts: 0, hsd: 24, hsm: 11.4, ghad: 221, gham: 25.6, decd: 19, decm: 2.6, decdir: 1 },
            { name: "POLARIS", th: 19, tm: 23, ts: 40, hsd: 14, hsm: 20.9, ghad: 69, gham: 20.0, decd: 89, decm: 20.5, decdir: 1 }
        ]
    },
    {
        name: "Example 3: December 2026 (Worksheet P3)",
        ap: { latDir: -1, latD: 35, latM: 20, lonDir: -1, lonD: 79, lonM: 50 },
        ship: { cog: 64, sog: 13, hoe: 10, ie: 1.4, ieArc: -1 },
        date: { day: 14, mon: 12, yr: 2026 },
        zone: { sign: 1, h: 5, m: 0, s: 0 },
        bodies: [
            { name: "ACHERNAR", th: 20, tm: 18, ts: 40, hsd: 68, hsm: 5.4, ghad: 78, gham: 42.1, decd: 57, decm: 6.2, decdir: -1 },
            { name: "CANOPUS", th: 20, tm: 20, ts: 20, hsd: 37, hsm: 42.8, ghad: 7, gham: 45.5, decd: 52, decm: 42.5, decdir: -1 },
            { name: "FOMALHAUT", th: 20, tm: 22, ts: 0, hsd: 56, hsm: 8.5, ghad: 119, gham: 26.3, decd: 29, decm: 28.9, decdir: -1 },
            { name: "ACRUX", th: 20, tm: 23, ts: 40, hsd: 9, hsm: 33.2, ghad: 277, gham: 37.0, decd: 63, decm: 14.7, decdir: -1 }
        ]
    },
    {
        name: "Example 4: March 2026 (User)",
        ap: { latDir: 1, latD: 13, latM: 0, lonDir: 1, lonD: 82, lonM: 30 },
        ship: { cog: 280, sog: 15, hoe: 12, ie: 1.8, ieArc: -1 },
        date: { day: 25, mon: 3, yr: 2026 },
        zone: { sign: -1, h: 5, m: 30, s: 0 },
        bodies: [
            { name: "VEGA", th: 19, tm: 11, ts: 20, hsd: 37, hsm: 20.3, ghad: 78, gham: 42.1, decd: 57, decm: 6.2, decdir: -1 },
            { name: "ALTAIR", th: 19, tm: 14, ts: 30, hsd: 25, hsm: 15.6, ghad: 51, gham: 32.4, decd: 8, decm: 57.0, decdir: 1 },
            { name: "ARCTURUS", th: 19, tm: 17, ts: 40, hsd: 40, hsm: 12.8, ghad: 110, gham: 15.6, decd: 19, decm: 2.5, decdir: 1 },
            { name: "POLARIS", th: 19, tm: 21, ts: 0, hsd: 13, hsm: 2.4, ghad: 70, gham: 3.5, decd: 89, decm: 21.1, decdir: 1 }
        ]
    }
];

function loadStarScenario(idx) {
    const sc = starScenarios[idx];
    if (!sc) return;

    // Common Ship Inputs
    document.getElementById('st-ap-latdir').value = sc.ap.latDir;
    document.getElementById('st-ap-latd').value = sc.ap.latD;
    document.getElementById('st-ap-latm').value = sc.ap.latM;
    document.getElementById('st-ap-londir').value = sc.ap.lonDir;
    document.getElementById('st-ap-lond').value = sc.ap.lonD;
    document.getElementById('st-ap-lonm').value = sc.ap.lonM;

    document.getElementById('st-ap-cog').value = sc.ship.cog;
    document.getElementById('st-ap-sog').value = sc.ship.sog;
    document.getElementById('st-ap-hoe').value = sc.ship.hoe;
    document.getElementById('st-ap-ie').value = sc.ship.ie;
    document.getElementById('st-ap-iearc').value = sc.ship.ieArc;

    document.getElementById('st-date-day').value = sc.date.day;
    document.getElementById('st-date-mon').value = sc.date.mon;
    document.getElementById('st-date-yr').value = sc.date.yr;

    document.getElementById('st-zone-sign').value = sc.zone.sign;
    document.getElementById('st-zone-h').value = sc.zone.h;
    document.getElementById('st-zone-m').value = sc.zone.m;
    document.getElementById('st-zone-s').value = sc.zone.s;

    // We need to update the STAR_DEFAULTS or just set the values directly after building
    // To make it clean, let's update STAR_DEFAULTS temporarily and rebuild panels
    for (let i = 0; i < 4; i++) {
        const b = sc.bodies[i];
        STAR_NAMES[i] = b.name;
        STAR_DEFAULTS[i] = {
            t_h: b.th, t_m: b.tm, t_s: b.ts,
            hsd: b.hsd, hsm: b.hsm,
            ghad: b.ghad, gham: b.gham,
            decd: b.decd, decm: b.decm, decdir: b.decdir
        };
    }

    nsBuildStarPanels();

    // Set Moon limb if applicable
    for (let i = 0; i < 4; i++) {
        if (sc.bodies[i].name === "MOON" && sc.bodies[i].limb) {
            document.getElementById(`st${i}-moon-limb`).value = sc.bodies[i].limb;
            document.getElementById(`st${i}-moonlimb-wrap`).style.display = 'block';
        }
    }

    // Clear cache and populate with scenario values if provided
    for (let i = 0; i < 4; i++) {
        const b = sc.bodies[i];
        if (b.hp) {
            _nsEphemCache[`st${i}`] = { hpMin: b.hp };
        } else {
            delete _nsEphemCache[`st${i}`];
        }
    }

    console.log("Star Scenario loaded:", sc.name);

    // Auto-calculate everything
    setTimeout(() => {
        for (let i = 0; i < 4; i++) {
            nsStarCompute(i);
        }
        nsFourStarFix();
    }, 200);
}
