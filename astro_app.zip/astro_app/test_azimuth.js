function rad(deg) { return deg * Math.PI / 180; }
function deg(rad) { return rad * 180 / Math.PI; }

let lat = -20.1666667; // 20°10' S
let dec = 22.745;      // 22°44.7' N
let gha = 234.8816667; // 234°52.9'
let lon = 95.3333333;  // 95°20' E

let lha = gha + lon;
lha = ((lha % 360) + 360) % 360;

console.log("LHA: " + lha);

let sinHc = Math.sin(rad(lat)) * Math.sin(rad(dec)) + Math.cos(rad(lat)) * Math.cos(rad(dec)) * Math.cos(rad(lha));
let hc = deg(Math.asin(sinHc));

console.log("Hc: " + hc);

// Test formula 1: User's tan(Z)
let Z_y = Math.sin(rad(lha));
let Z_x = Math.cos(rad(lha)) * Math.sin(rad(lat)) - Math.tan(rad(dec)) * Math.cos(rad(lat));
let zAngle = deg(Math.atan2(Z_y, Z_x));
console.log("User formula atan2: " + zAngle);

// Test formula 2: Standard atan2 for Zn
let az_y = Math.sin(rad(360 - lha)); // or -Math.sin(rad(lha))
let az_x = Math.cos(rad(lat)) * Math.tan(rad(dec)) - Math.sin(rad(lat)) * Math.cos(rad(lha));
let zn_atan2 = deg(Math.atan2(az_y, az_x));
zn_atan2 = (zn_atan2 + 360) % 360;
console.log("Standard atan2 Zn: " + zn_atan2);

// Test formula 3: The one currently in code
const cosZ = (Math.sin(rad(dec)) - Math.sin(rad(lat)) * Math.sin(rad(hc))) / (Math.cos(rad(lat)) * Math.cos(rad(hc)));
let zAngleCurrent = deg(Math.acos(Math.max(-1, Math.min(1, cosZ))));
console.log("Current acos Z: " + zAngleCurrent);
let znCurrent;
if (lat >= 0) {
    znCurrent = (lha > 180) ? zAngleCurrent : 360 - zAngleCurrent;
} else {
    znCurrent = (lha > 180) ? 180 - zAngleCurrent : 180 + zAngleCurrent;
}
console.log("Current Zn: " + znCurrent);
